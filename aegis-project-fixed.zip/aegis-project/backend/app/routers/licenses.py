import secrets
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..security import get_current_developer

router = APIRouter(prefix="/licenses", tags=["licenses"])


def generate_license_key() -> str:
    # Groups of 5 uppercase alphanumerics, e.g. AB12C-3D4E5-...
    raw = secrets.token_hex(10).upper()
    return "-".join(raw[i:i + 5] for i in range(0, len(raw), 5))


@router.post("", response_model=schemas.LicenseOut)
def create_license(
    payload: schemas.LicenseCreate,
    db: Session = Depends(get_db),
    developer: models.Developer = Depends(get_current_developer),
):
    lic = models.License(
        license_key=generate_license_key(),
        product_name=payload.product_name,
        customer_name=payload.customer_name,
        max_devices=payload.max_devices,
        expires_at=payload.expires_at,
        developer_id=developer.id,
    )
    db.add(lic)
    db.commit()
    db.refresh(lic)
    return lic


@router.get("", response_model=List[schemas.LicenseOut])
def list_licenses(
    db: Session = Depends(get_db),
    developer: models.Developer = Depends(get_current_developer),
):
    return db.query(models.License).filter(models.License.developer_id == developer.id).all()


def _get_owned_license(license_id: int, db: Session, developer: models.Developer) -> models.License:
    lic = db.query(models.License).filter(
        models.License.id == license_id, models.License.developer_id == developer.id
    ).first()
    if not lic:
        raise HTTPException(status_code=404, detail="License not found")
    return lic


@router.patch("/{license_id}/block", response_model=schemas.LicenseOut)
def block_license(
    license_id: int,
    db: Session = Depends(get_db),
    developer: models.Developer = Depends(get_current_developer),
):
    lic = _get_owned_license(license_id, db, developer)
    lic.status = "blocked"
    db.commit()
    db.refresh(lic)
    return lic


@router.post("/{license_id}/expected-hashes")
def add_expected_hash(
    license_id: int,
    payload: schemas.ExpectedHashCreate,
    db: Session = Depends(get_db),
    developer: models.Developer = Depends(get_current_developer),
):
    lic = _get_owned_license(license_id, db, developer)

    existing = db.query(models.ExpectedFileHash).filter(
        models.ExpectedFileHash.license_id == lic.id,
        models.ExpectedFileHash.file_name == payload.file_name,
    ).first()
    if existing:
        existing.expected_hash = payload.expected_hash
    else:
        db.add(models.ExpectedFileHash(
            license_id=lic.id, file_name=payload.file_name, expected_hash=payload.expected_hash
        ))
    db.commit()
    return {"ok": True}
