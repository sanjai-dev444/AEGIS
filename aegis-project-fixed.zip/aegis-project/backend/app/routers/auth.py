from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..security import create_access_token, hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=schemas.Token)
def register(payload: schemas.DeveloperCreate, db: Session = Depends(get_db)):
    existing = db.query(models.Developer).filter(models.Developer.username == payload.username).first()
    if existing:
        raise HTTPException(status_code=400, detail="Username already registered")

    developer = models.Developer(
        username=payload.username,
        hashed_password=hash_password(payload.password),
        company_name=payload.company_name,
    )
    db.add(developer)
    db.commit()
    db.refresh(developer)

    token = create_access_token({"sub": developer.username})
    return schemas.Token(access_token=token)


@router.post("/login", response_model=schemas.Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    developer = db.query(models.Developer).filter(models.Developer.username == form_data.username).first()
    if not developer or not verify_password(form_data.password, developer.hashed_password):
        raise HTTPException(status_code=401, detail="Incorrect username or password")

    token = create_access_token({"sub": developer.username})
    return schemas.Token(access_token=token)
