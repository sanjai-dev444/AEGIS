from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..risk_engine import score_verification, score_integrity, classify

router = APIRouter(tags=["client"])


@router.post("/verify", response_model=schemas.VerifyResponse)
def verify_license(payload: schemas.VerifyRequest, db: Session = Depends(get_db)):
    """
    Called by the client app on launch (and periodically thereafter).
    No developer auth here — this is the endpoint the *game/app itself* calls.
    """
    lic = db.query(models.License).filter(models.License.license_key == payload.license).first()
    if not lic:
        return schemas.VerifyResponse(status="Invalid", expires=None, risk=100, message="License not found")

    if lic.status == "blocked":
        return schemas.VerifyResponse(status="Blocked", expires=lic.expires_at, risk=100, message="License has been blocked")

    if lic.expires_at and lic.expires_at < datetime.utcnow():
        lic.status = "expired"
        db.commit()
        return schemas.VerifyResponse(status="Expired", expires=lic.expires_at, risk=50, message="License has expired")

    device = db.query(models.Device).filter(
        models.Device.license_id == lic.id, models.Device.device_id == payload.device_id
    ).first()
    is_new_device = device is None
    if is_new_device:
        device = models.Device(license_id=lic.id, device_id=payload.device_id)
        db.add(device)
    else:
        device.last_seen = datetime.utcnow()

    existing_device_count = db.query(models.Device).filter(models.Device.license_id == lic.id).count()
    effective_device_count = existing_device_count + (1 if is_new_device else 0)

    score, reasons = score_verification(is_new_device, effective_device_count, lic.max_devices)

    db.add(models.Activation(
        license_id=lic.id,
        device_id=payload.device_id,
        version=payload.version,
        risk_score=score,
        status=classify(score),
    ))
    db.commit()

    return schemas.VerifyResponse(
        status="Valid",
        expires=lic.expires_at,
        risk=score,
        message="; ".join(reasons) if reasons else None,
    )


@router.post("/integrity", response_model=schemas.IntegrityResponse)
def check_integrity(payload: schemas.IntegrityRequest, db: Session = Depends(get_db)):
    """
    Called by the client's integrity checker with hashes of critical files.
    The server holds the source of truth (expected hashes) — the client never
    decides for itself whether it's been tampered with.
    """
    lic = db.query(models.License).filter(models.License.license_key == payload.license).first()
    if not lic:
        raise HTTPException(status_code=404, detail="License not found")

    expected = {
        h.file_name: h.expected_hash
        for h in db.query(models.ExpectedFileHash).filter(models.ExpectedFileHash.license_id == lic.id).all()
    }

    mismatches = []
    for file_name, received_hash in payload.file_hashes.items():
        expected_hash = expected.get(file_name)
        if expected_hash and expected_hash != received_hash:
            mismatches.append(file_name)
            db.add(models.IntegrityAlert(
                license_id=lic.id,
                device_id=payload.device_id,
                file_name=file_name,
                expected_hash=expected_hash,
                received_hash=received_hash,
            ))

    score, _ = score_integrity(len(mismatches))
    db.commit()

    return schemas.IntegrityResponse(
        status="Mismatch detected" if mismatches else "OK",
        mismatches=mismatches,
        risk=score,
    )
