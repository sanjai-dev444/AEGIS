from datetime import datetime, time
from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..security import get_current_developer

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


def _developer_license_ids(db: Session, developer: models.Developer):
    return [lic.id for lic in db.query(models.License).filter(models.License.developer_id == developer.id).all()]


@router.get("/summary", response_model=schemas.DashboardSummary)
def summary(
    db: Session = Depends(get_db),
    developer: models.Developer = Depends(get_current_developer),
):
    license_ids = _developer_license_ids(db, developer)
    total_licenses = len(license_ids)

    today_start = datetime.combine(datetime.utcnow().date(), time.min)
    activations_today = 0
    open_alerts = 0
    if license_ids:
        activations_today = db.query(models.Activation).filter(
            models.Activation.license_id.in_(license_ids),
            models.Activation.timestamp >= today_start,
        ).count()
        open_alerts = db.query(models.IntegrityAlert).filter(
            models.IntegrityAlert.license_id.in_(license_ids),
            models.IntegrityAlert.resolved == False,  # noqa: E712
        ).count()

    return schemas.DashboardSummary(
        total_licenses=total_licenses,
        activations_today=activations_today,
        open_alerts=open_alerts,
    )


@router.get("/activations", response_model=List[schemas.ActivationOut])
def activations(
    db: Session = Depends(get_db),
    developer: models.Developer = Depends(get_current_developer),
):
    license_ids = _developer_license_ids(db, developer)
    if not license_ids:
        return []
    return db.query(models.Activation).filter(
        models.Activation.license_id.in_(license_ids)
    ).order_by(models.Activation.timestamp.desc()).limit(50).all()


@router.get("/alerts", response_model=List[schemas.AlertOut])
def alerts(
    db: Session = Depends(get_db),
    developer: models.Developer = Depends(get_current_developer),
):
    license_ids = _developer_license_ids(db, developer)
    if not license_ids:
        return []
    return db.query(models.IntegrityAlert).filter(
        models.IntegrityAlert.license_id.in_(license_ids)
    ).order_by(models.IntegrityAlert.timestamp.desc()).limit(50).all()
