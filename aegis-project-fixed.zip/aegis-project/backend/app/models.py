from datetime import datetime
from sqlalchemy import Column, String, Integer, DateTime, Boolean, ForeignKey
from sqlalchemy.orm import relationship

from .database import Base


class Developer(Base):
    """A registered developer/company account that owns licenses."""
    __tablename__ = "developers"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    company_name = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    licenses = relationship("License", back_populates="owner")


class License(Base):
    """A single license key issued to a customer for a product."""
    __tablename__ = "licenses"
    id = Column(Integer, primary_key=True, index=True)
    license_key = Column(String, unique=True, index=True, nullable=False)
    product_name = Column(String, nullable=False)
    customer_name = Column(String, nullable=False)
    status = Column(String, default="active")  # active | blocked | expired
    max_devices = Column(Integer, default=1)
    expires_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    developer_id = Column(Integer, ForeignKey("developers.id"))

    owner = relationship("Developer", back_populates="licenses")
    devices = relationship("Device", back_populates="license", cascade="all, delete-orphan")
    activations = relationship("Activation", back_populates="license", cascade="all, delete-orphan")
    integrity_alerts = relationship("IntegrityAlert", back_populates="license", cascade="all, delete-orphan")
    expected_hashes = relationship("ExpectedFileHash", back_populates="license", cascade="all, delete-orphan")


class Device(Base):
    """A device fingerprint that has activated a given license."""
    __tablename__ = "devices"
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String, index=True, nullable=False)
    license_id = Column(Integer, ForeignKey("licenses.id"))
    first_seen = Column(DateTime, default=datetime.utcnow)
    last_seen = Column(DateTime, default=datetime.utcnow)
    is_blocked = Column(Boolean, default=False)

    license = relationship("License", back_populates="devices")


class Activation(Base):
    """A log entry for every /verify call — the raw feed the dashboard reads."""
    __tablename__ = "activations"
    id = Column(Integer, primary_key=True, index=True)
    license_id = Column(Integer, ForeignKey("licenses.id"))
    device_id = Column(String, nullable=False)
    version = Column(String, nullable=True)
    risk_score = Column(Integer, default=0)
    status = Column(String, default="Low")  # Low | Medium | High risk classification
    timestamp = Column(DateTime, default=datetime.utcnow)

    license = relationship("License", back_populates="activations")


class IntegrityAlert(Base):
    """Raised whenever a client-reported file hash doesn't match the expected value."""
    __tablename__ = "integrity_alerts"
    id = Column(Integer, primary_key=True, index=True)
    license_id = Column(Integer, ForeignKey("licenses.id"))
    device_id = Column(String, nullable=False)
    file_name = Column(String, nullable=False)
    expected_hash = Column(String, nullable=False)
    received_hash = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    resolved = Column(Boolean, default=False)

    license = relationship("License", back_populates="integrity_alerts")


class ExpectedFileHash(Base):
    """The known-good hash for a given file, set by the developer per license/product."""
    __tablename__ = "expected_file_hashes"
    id = Column(Integer, primary_key=True, index=True)
    license_id = Column(Integer, ForeignKey("licenses.id"))
    file_name = Column(String, nullable=False)
    expected_hash = Column(String, nullable=False)

    license = relationship("License", back_populates="expected_hashes")
