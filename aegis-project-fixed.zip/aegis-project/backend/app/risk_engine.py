"""
Rule-based risk scoring.

Deliberately not a black-box model: every point on the score is traceable to
a specific signal, and the reasons list is returned to the developer, not
just a number. That's the pitch — a shared/cracked license is flagged and
explained, not silently blocked (which just teaches the pirate what tripped
the check).
"""

RISK_RULES = {
    "new_device": 10,
    "device_limit_exceeded": 30,
    "hash_mismatch": 40,
}

RISK_THRESHOLDS = [
    (0, 19, "Low"),
    (20, 49, "Medium"),
    (50, 10_000, "High"),
]


def classify(score: int) -> str:
    for low, high, label in RISK_THRESHOLDS:
        if low <= score <= high:
            return label
    return "High"


def score_verification(is_new_device: bool, device_count: int, max_devices: int):
    """Score a single /verify call. Returns (score, reasons).

    device_limit_exceeded is only applied to *new* devices — the ones
    actually pushing the count over the limit.  A known device re-verifying
    on an already-over-limit license is not itself a new suspicious event;
    the excess was already captured when the offending device first registered.
    """
    score = 0
    reasons = []
    if is_new_device:
        score += RISK_RULES["new_device"]
        reasons.append("New device seen for this license")
        if device_count > max_devices:
            score += RISK_RULES["device_limit_exceeded"]
            reasons.append(f"Device count ({device_count}) exceeds license limit ({max_devices})")
    return score, reasons


def score_integrity(mismatch_count: int):
    """Score an /integrity call. Returns (score, reasons)."""
    if mismatch_count == 0:
        return 0, []
    score = RISK_RULES["hash_mismatch"] * mismatch_count
    reasons = [f"{mismatch_count} file(s) failed integrity check"]
    return score, reasons
