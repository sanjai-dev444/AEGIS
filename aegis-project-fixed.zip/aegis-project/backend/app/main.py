from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import Base, engine
from .routers import auth as auth_router, licenses, verify, dashboard

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Aegis License Protection API",
    description="AI-powered software license protection & integrity monitoring platform.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten to the dashboard's real origin before any real deployment
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router.router)
app.include_router(licenses.router)
app.include_router(verify.router)
app.include_router(dashboard.router)


@app.get("/")
def root():
    return {"status": "Aegis API running"}
