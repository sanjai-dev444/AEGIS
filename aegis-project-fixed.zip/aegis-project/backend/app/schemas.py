from datetime import datetime
from typing import Dict, List, Optional

from pydantic import BaseModel


# ---------- Auth ----------

class DeveloperCreate(BaseModel):
    username: str
    password: str
    company_name: Optional[str] = None


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---------- Licenses ----------

class LicenseCreate(BaseModel):
    product_name: str
    customer_name: str
    max_devices: int = 1
    expires_at: Optional[datetime] = None


class LicenseOut(BaseModel):
    id: int
    license_key: str
    product_name: str
    customer_name: str
    status: str
    max_devices: int
    expires_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ExpectedHashCreate(BaseModel):
    file_name: str
    expected_hash: str


# ---------- Client-facing: /verify, /integrity ----------

class VerifyRequest(BaseModel):
    license: str
    device_id: str
    version: Optional[str] = None


class VerifyResponse(BaseModel):
    status: str
    expires: Optional[datetime] = None
    risk: int
    message: Optional[str] = None


class IntegrityRequest(BaseModel):
    license: str
    device_id: str
    file_hashes: Dict[str, str]


class IntegrityResponse(BaseModel):
    status: str
    mismatches: List[str]
    risk: int


# ---------- Dashboard ----------

class DashboardSummary(BaseModel):
    total_licenses: int
    activations_today: int
    open_alerts: int


class ActivationOut(BaseModel):
    id: int
    device_id: str
    version: Optional[str] = None
    risk_score: int
    status: str
    timestamp: datetime

    class Config:
        from_attributes = True


class AlertOut(BaseModel):
    id: int
    device_id: str
    file_name: str
    expected_hash: str
    received_hash: str
    timestamp: datetime
    resolved: bool

    class Config:
        from_attributes = True
