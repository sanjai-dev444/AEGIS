"""
Runs the exact hackathon demo flow against a LIVE server (not TestClient),
so you can use this on stage: register -> create license -> activate ->
second device (risk jumps) -> integrity mismatch (simulated crack) -> dashboard.

Usage:
    1. In one terminal: uvicorn app.main:app --reload
    2. In another:      python demo_seed.py
"""
import requests

BASE = "http://127.0.0.1:8000"


def main():
    print("1. Registering developer account...")
    r = requests.post(f"{BASE}/auth/register", json={
        "username": "demo_dev", "password": "pass1234", "company_name": "Demo Studio"
    })
    if r.status_code != 200:
        # already registered from a previous run — log in instead
        r = requests.post(f"{BASE}/auth/login", data={"username": "demo_dev", "password": "pass1234"})
    token = r.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    print("   done.\n")

    print("2. Creating a license (max_devices=1)...")
    r = requests.post(f"{BASE}/licenses", json={
        "product_name": "Demo Game", "customer_name": "Alice", "max_devices": 1
    }, headers=headers)
    lic = r.json()
    print(f"   license: {lic['license_key']}\n")

    print("3. Registering expected file hash for integrity checks...")
    requests.post(f"{BASE}/licenses/{lic['id']}/expected-hashes", json={
        "file_name": "game.exe", "expected_hash": "abc123"
    }, headers=headers)
    print("   done.\n")

    print("4. Client activates from device A...")
    r = requests.post(f"{BASE}/verify", json={
        "license": lic["license_key"], "device_id": "device-A", "version": "1.0"
    })
    print(f"   {r.json()}\n")

    print("5. SAME license activates from device B (exceeds 1-device limit)...")
    r = requests.post(f"{BASE}/verify", json={
        "license": lic["license_key"], "device_id": "device-B", "version": "1.0"
    })
    print(f"   {r.json()}   <- risk score jumps\n")

    print("6. Device B reports a modified game.exe (simulated crack)...")
    r = requests.post(f"{BASE}/integrity", json={
        "license": lic["license_key"], "device_id": "device-B",
        "file_hashes": {"game.exe": "TAMPERED_HASH_1234"}
    })
    print(f"   {r.json()}\n")

    print("7. Dashboard summary now shows:")
    r = requests.get(f"{BASE}/dashboard/summary", headers=headers)
    print(f"   {r.json()}\n")

    print("Demo seeded. Point the dashboard frontend at this API and refresh.")


if __name__ == "__main__":
    main()
