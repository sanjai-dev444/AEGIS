# Aegis backend

FastAPI backend for the Aegis license protection & integrity monitoring platform.
Tested end-to-end: register → license → verify → risk scoring → integrity check → dashboard.

## Setup

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Server runs at `http://127.0.0.1:8000`. Interactive API docs (Swagger UI) at
`http://127.0.0.1:8000/docs` — useful for the pitch if the frontend isn't ready yet.

Database is SQLite (`aegis.db`, created automatically on first run). No external DB
server needed. To move to Postgres later, only `app/database.py` changes.

## Run the demo flow

```bash
# terminal 1
uvicorn app.main:app --reload

# terminal 2
python demo_seed.py
```

This walks through the exact judge-facing demo: create a license, activate it,
activate a second device on a 1-device license (risk jumps), simulate a modified
binary (integrity alert fires), then pull the dashboard summary.

## Endpoints

### Developer-facing (require a Bearer token from `/auth/login`)
| Method | Path | Purpose |
|---|---|---|
| POST | `/auth/register` | Create a developer account, returns a token |
| POST | `/auth/login` | Login (OAuth2 form: `username`, `password`), returns a token |
| POST | `/licenses` | Generate a new license key |
| GET | `/licenses` | List your licenses |
| PATCH | `/licenses/{id}/block` | Block a license |
| POST | `/licenses/{id}/expected-hashes` | Register the known-good hash for a file |
| GET | `/dashboard/summary` | Totals: licenses, activations today, open alerts |
| GET | `/dashboard/activations` | Recent verification log with risk scores |
| GET | `/dashboard/alerts` | Integrity mismatch alerts |

### Client-facing (called by the game/app itself, no auth)
| Method | Path | Purpose |
|---|---|---|
| POST | `/verify` | `{license, device_id, version}` → `{status, expires, risk}` |
| POST | `/integrity` | `{license, device_id, file_hashes}` → `{status, mismatches, risk}` |

## Risk scoring (`app/risk_engine.py`)

Rule-based and explainable on purpose — every point is traceable to a named signal,
and the reasons are returned alongside the score rather than a silent block:

| Signal | Points |
|---|---|
| New device seen | +10 |
| Device count exceeds license's `max_devices` | +30 |
| File hash mismatch (integrity check) | +40 per file |

`0-19` = Low, `20-49` = Medium, `50+` = High.

## What's deliberately not built (cut for hackathon scope)

- ML anomaly model (Isolation Forest) — rule-based scoring above covers the demo
  and is easier to defend live in front of judges than a model you can't fully explain
- AI-generated alert explanations — the reasons list already does this in plain text
- Unreal Engine client integration — the Python client (build next) covers the demo;
  UE5 hookup is a good "here's how this plugs into a real engine" slide, not a live build

## Next steps

1. Client app (Python) that calls `/verify` on launch and `/integrity` periodically
2. Dashboard frontend (React + Chart.js) against `/dashboard/*`
3. Auth flow for the dashboard login screen
