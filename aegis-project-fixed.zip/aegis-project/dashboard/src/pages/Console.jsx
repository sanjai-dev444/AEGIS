import { useEffect, useState, useCallback } from 'react'
import { getSummary, getActivations, getAlerts, getLicenses, clearToken } from '../api.js'
import StatTile from '../components/StatTile.jsx'
import RiskGauge from '../components/RiskGauge.jsx'
import RiskBarChart from '../components/RiskBarChart.jsx'
import ActivationsLog from '../components/ActivationsLog.jsx'
import AlertsLog from '../components/AlertsLog.jsx'

const POLL_MS = 5000

export default function Console({ onLoggedOut }) {
  const [summary, setSummary] = useState(null)
  const [licenses, setLicenses] = useState([])
  const [activations, setActivations] = useState([])
  const [alerts, setAlerts] = useState([])
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    try {
      const [s, l, a, al] = await Promise.all([
        getSummary(),
        getLicenses(),
        getActivations(),
        getAlerts(),
      ])
      setSummary(s)
      setLicenses(l)
      setActivations(a)
      setAlerts(al)
      setError('')
    } catch (err) {
      setError(err.message)
      if (err.message.includes('Session expired')) onLoggedOut()
    }
  }, [onLoggedOut])

  useEffect(() => {
    load()
    const id = setInterval(load, POLL_MS)
    return () => clearInterval(id)
  }, [load])

  const activeLicenses = licenses.filter((l) => l.status === 'active').length
  const blockedLicenses = licenses.filter((l) => l.status === 'blocked').length

  const aggregateRisk = activations.length
    ? Math.round(activations.slice(0, 10).reduce((sum, a) => sum + a.risk_score, 0) / Math.min(10, activations.length))
    : 0

  function handleLogout() {
    clearToken()
    onLoggedOut()
  }

  return (
    <div className="min-h-screen bg-base text-ink">
      <header className="border-b border-panel-line px-6 py-4 flex items-center justify-between">
        <div>
          <div className="text-signal font-mono text-sm tracking-[0.3em]">AEGIS</div>
          <div className="text-muted text-xs font-mono">License &amp; integrity console</div>
        </div>
        <button
          onClick={handleLogout}
          className="text-muted text-sm font-mono hover:text-ink transition"
        >
          Log out
        </button>
      </header>

      <main className="px-6 py-6 max-w-6xl mx-auto space-y-6">
        {error && (
          <div className="bg-danger/10 border border-danger/40 text-danger text-sm font-mono rounded-md px-4 py-2">
            {error}
          </div>
        )}

        {summary && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <StatTile label="Licenses" value={summary.total_licenses} />
            <StatTile label="Active" value={activeLicenses} accent="calm" />
            <StatTile label="Blocked" value={blockedLicenses} accent="danger" />
            <StatTile label="Activations today" value={summary.activations_today} />
            <StatTile label="Open alerts" value={summary.open_alerts} accent="signal" />
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-panel panel-texture border border-panel-line rounded-lg p-4 flex flex-col items-center justify-center">
            <RiskGauge score={aggregateRisk} label="Aggregate risk (last 10)" />
          </div>
          <div className="md:col-span-2 bg-panel panel-texture border border-panel-line rounded-lg p-4">
            <div className="text-xs uppercase tracking-wider text-muted font-mono mb-3">
              Activations by risk tier
            </div>
            <RiskBarChart activations={activations} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-panel panel-texture border border-panel-line rounded-lg p-4">
            <div className="text-xs uppercase tracking-wider text-muted font-mono mb-3">
              Recent activations
            </div>
            <ActivationsLog activations={activations} />
          </div>
          <div className="bg-panel panel-texture border border-panel-line rounded-lg p-4">
            <div className="text-xs uppercase tracking-wider text-muted font-mono mb-3">
              Integrity alerts
            </div>
            <AlertsLog alerts={alerts} />
          </div>
        </div>
      </main>
    </div>
  )
}
