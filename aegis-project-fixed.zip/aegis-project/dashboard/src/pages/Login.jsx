import { useState } from 'react'
import { login, register } from '../api.js'

export default function Login({ onAuthed }) {
  const [mode, setMode] = useState('login') // 'login' | 'register'
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [company, setCompany] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      if (mode === 'login') {
        await login(username, password)
      } else {
        await register(username, password, company)
      }
      onAuthed()
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="min-h-screen bg-base flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="text-signal font-mono text-sm tracking-[0.3em] mb-1">AEGIS</div>
          <h1 className="text-ink text-lg font-medium">Developer console access</h1>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-panel panel-texture border border-panel-line rounded-lg p-6 space-y-4"
        >
          <div>
            <label className="block text-xs uppercase tracking-wider text-muted font-mono mb-1">
              Username
            </label>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              className="w-full bg-base border border-panel-line rounded-md px-3 py-2 text-ink font-mono text-sm focus:border-signal outline-none"
              placeholder="demo_dev"
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wider text-muted font-mono mb-1">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full bg-base border border-panel-line rounded-md px-3 py-2 text-ink font-mono text-sm focus:border-signal outline-none"
              placeholder="••••••••"
            />
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-xs uppercase tracking-wider text-muted font-mono mb-1">
                Company (optional)
              </label>
              <input
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                className="w-full bg-base border border-panel-line rounded-md px-3 py-2 text-ink font-mono text-sm focus:border-signal outline-none"
                placeholder="Demo Studio"
              />
            </div>
          )}

          {error && <p className="text-danger text-sm font-mono">{error}</p>}

          <button
            type="submit"
            disabled={busy}
            className="w-full bg-signal text-base font-medium rounded-md py-2 hover:brightness-110 transition disabled:opacity-50"
          >
            {busy ? 'Working…' : mode === 'login' ? 'Log in' : 'Create account'}
          </button>
        </form>

        <button
          onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
          className="w-full text-center text-muted text-sm mt-4 hover:text-ink transition"
        >
          {mode === 'login' ? 'New here? Create an account' : 'Already have an account? Log in'}
        </button>
      </div>
    </div>
  )
}
