// Fetch wrapper — auth token storage and all API calls.
// Base URL points at the Aegis backend (see the backend project's README).
const API_BASE_URL = 'http://127.0.0.1:8000'

const TOKEN_KEY = 'aegis_token'

export function getToken() {
  return localStorage.getItem(TOKEN_KEY)
}

export function setToken(token) {
  localStorage.setItem(TOKEN_KEY, token)
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY)
}

async function request(path, { method = 'GET', body, form = false, auth = true } = {}) {
  const headers = {}
  if (auth) {
    const token = getToken()
    if (token) headers['Authorization'] = `Bearer ${token}`
  }

  let payload = body
  if (body && !form) {
    headers['Content-Type'] = 'application/json'
    payload = JSON.stringify(body)
  } else if (body && form) {
    payload = new URLSearchParams(body)
  }

  const res = await fetch(`${API_BASE_URL}${path}`, { method, headers, body: payload })

  if (res.status === 401) {
    clearToken()
    throw new Error('Session expired — please log in again.')
  }

  if (!res.ok) {
    let detail = res.statusText
    try {
      const data = await res.json()
      detail = data.detail || detail
    } catch {
      // response wasn't JSON — fall back to statusText
    }
    throw new Error(typeof detail === 'string' ? detail : JSON.stringify(detail))
  }

  if (res.status === 204) return null
  return res.json()
}

// ---------- Auth ----------

export async function register(username, password, company) {
  const data = await request('/auth/register', {
    method: 'POST',
    auth: false,
    body: { username, password, company_name: company || null },
  })
  setToken(data.access_token)
  return data
}

export async function login(username, password) {
  const data = await request('/auth/login', {
    method: 'POST',
    auth: false,
    form: true,
    body: { username, password },
  })
  setToken(data.access_token)
  return data
}

// ---------- Licenses ----------

export function getLicenses() {
  return request('/licenses')
}

export function createLicense({ product_name, customer_name, max_devices = 1, expires_at = null }) {
  return request('/licenses', {
    method: 'POST',
    body: { product_name, customer_name, max_devices, expires_at },
  })
}

export function blockLicense(licenseId) {
  return request(`/licenses/${licenseId}/block`, { method: 'PATCH' })
}

export function addExpectedHash(licenseId, fileName, expectedHash) {
  return request(`/licenses/${licenseId}/expected-hashes`, {
    method: 'POST',
    body: { file_name: fileName, expected_hash: expectedHash },
  })
}

// ---------- Dashboard ----------
// NOTE: the backend's /dashboard/summary returns only
// { total_licenses, activations_today, open_alerts } — active/blocked
// license counts aren't precomputed server-side, so the Console derives
// them from the /licenses list instead.

export function getSummary() {
  return request('/dashboard/summary')
}

export function getActivations() {
  return request('/dashboard/activations')
}

export function getAlerts() {
  return request('/dashboard/alerts')
}
