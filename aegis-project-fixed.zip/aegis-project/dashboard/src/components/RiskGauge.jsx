// A radial sweep gauge — the console's signature element. Reads the current
// aggregate risk the way an analog instrument reads pressure or signal
// strength, rather than a generic donut/progress ring.
export default function RiskGauge({ score = 0, label = 'Aggregate risk' }) {
  const clamped = Math.max(0, Math.min(100, score))
  const angle = -120 + (clamped / 100) * 240 // sweep from -120deg to +120deg
  const color = clamped < 20 ? '#3FC1C9' : clamped < 50 ? '#F2A93B' : '#E5484D'
  const tier = clamped < 20 ? 'Low' : clamped < 50 ? 'Medium' : 'High'

  const ticks = Array.from({ length: 11 }, (_, i) => -120 + i * 24)

  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 200 140" className="w-full max-w-[220px]">
        {/* Tick marks */}
        {ticks.map((deg, i) => {
          const rad = (deg * Math.PI) / 180
          const x1 = 100 + 78 * Math.sin(rad)
          const y1 = 110 - 78 * Math.cos(rad)
          const x2 = 100 + 68 * Math.sin(rad)
          const y2 = 110 - 68 * Math.cos(rad)
          return (
            <line
              key={i}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="#2A3240"
              strokeWidth="2"
            />
          )
        })}
        {/* Needle */}
        <g style={{ transition: 'transform 0.6s ease-out' }} transform={`rotate(${angle} 100 110)`}>
          <line x1="100" y1="110" x2="100" y2="38" stroke={color} strokeWidth="3" strokeLinecap="round" />
        </g>
        <circle cx="100" cy="110" r="6" fill={color} />
        <text x="100" y="95" textAnchor="middle" fontSize="22" fontFamily="IBM Plex Mono" fill="#E8EAED">
          {clamped}
        </text>
      </svg>
      <div className="text-center -mt-2">
        <div className="text-xs uppercase tracking-wider text-muted font-mono">{label}</div>
        <div className="text-sm font-mono" style={{ color }}>{tier}</div>
      </div>
    </div>
  )
}
