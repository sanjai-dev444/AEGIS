function formatTime(ts) {
  try {
    return new Date(ts).toLocaleTimeString()
  } catch {
    return ts
  }
}

export default function AlertsLog({ alerts = [] }) {
  if (!alerts.length) {
    return <div className="text-muted text-sm font-mono">No integrity alerts. All files verified.</div>
  }

  return (
    <div className="font-mono text-xs space-y-2 max-h-64 overflow-y-auto pr-1">
      {alerts.map((al) => (
        <div
          key={al.id}
          className="border border-danger/30 bg-danger/5 rounded-md px-2 py-1.5"
        >
          <div className="flex items-center justify-between">
            <span className="text-danger font-semibold">{al.file_name}</span>
            <span className="text-muted">{formatTime(al.timestamp)}</span>
          </div>
          <div className="text-muted truncate">device {al.device_id}</div>
          <div className="text-muted truncate">
            expected {al.expected_hash.slice(0, 12)}… received {al.received_hash.slice(0, 12)}…
          </div>
        </div>
      ))}
    </div>
  )
}
