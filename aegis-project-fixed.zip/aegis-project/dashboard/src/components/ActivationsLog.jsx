const STATUS_COLOR = {
  Low: 'text-calm',
  Medium: 'text-signal',
  High: 'text-danger',
}

function formatTime(ts) {
  try {
    return new Date(ts).toLocaleTimeString()
  } catch {
    return ts
  }
}

export default function ActivationsLog({ activations = [] }) {
  if (!activations.length) {
    return <div className="text-muted text-sm font-mono">No activations yet.</div>
  }

  return (
    <div className="font-mono text-xs space-y-1 max-h-64 overflow-y-auto pr-1">
      {activations.map((a) => (
        <div
          key={a.id}
          className="flex items-center justify-between gap-2 border-b border-panel-line/60 py-1 last:border-0"
        >
          <span className="text-muted shrink-0">{formatTime(a.timestamp)}</span>
          <span className="text-ink truncate flex-1">{a.device_id}</span>
          <span className="text-muted shrink-0">risk {a.risk_score}</span>
          <span className={`shrink-0 ${STATUS_COLOR[a.status] || 'text-ink'}`}>{a.status}</span>
        </div>
      ))}
    </div>
  )
}
