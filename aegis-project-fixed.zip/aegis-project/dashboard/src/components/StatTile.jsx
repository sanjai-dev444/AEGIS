const ACCENTS = {
  calm: 'text-calm',
  danger: 'text-danger',
  signal: 'text-signal',
  default: 'text-ink',
}

export default function StatTile({ label, value, accent = 'default' }) {
  return (
    <div className="bg-panel panel-texture border border-panel-line rounded-lg px-4 py-3">
      <div className="text-xs uppercase tracking-wider text-muted font-mono mb-1">{label}</div>
      <div className={`text-2xl font-mono font-semibold ${ACCENTS[accent] || ACCENTS.default}`}>
        {value ?? '—'}
      </div>
    </div>
  )
}
