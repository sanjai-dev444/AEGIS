import { useMemo, useRef, useEffect } from 'react'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
} from 'chart.js'
import { Bar } from 'react-chartjs-2'

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip)

const TIERS = ['Low', 'Medium', 'High']
const TIER_COLORS = {
  Low: '#3FC1C9',
  Medium: '#F2A93B',
  High: '#E5484D',
}

export default function RiskBarChart({ activations = [] }) {
  const prefersReducedMotion = useMemo(
    () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches,
    []
  )

  const counts = useMemo(() => {
    const tally = { Low: 0, Medium: 0, High: 0 }
    for (const a of activations) {
      if (tally[a.status] !== undefined) tally[a.status] += 1
    }
    return tally
  }, [activations])

  const data = {
    labels: TIERS,
    datasets: [
      {
        label: 'Activations',
        data: TIERS.map((t) => counts[t]),
        backgroundColor: TIERS.map((t) => TIER_COLORS[t]),
        borderRadius: 4,
        maxBarThickness: 56,
      },
    ],
  }

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    animation: prefersReducedMotion ? false : undefined,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#1A2029',
        titleFont: { family: 'IBM Plex Mono' },
        bodyFont: { family: 'IBM Plex Mono' },
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: '#8A94A6', font: { family: 'IBM Plex Mono', size: 11 } },
      },
      y: {
        beginAtZero: true,
        ticks: { color: '#8A94A6', precision: 0, font: { family: 'IBM Plex Mono', size: 11 } },
        grid: { color: '#232B36' },
      },
    },
  }

  const canvasWrapRef = useRef(null)

  useEffect(() => {
    // no-op: placeholder for future resize-driven tweaks
  }, [])

  return (
    <div ref={canvasWrapRef} className="h-56">
      <Bar data={data} options={options} />
    </div>
  )
}
