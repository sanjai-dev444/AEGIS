import { useState } from 'react'
import Login from './pages/Login.jsx'
import Console from './pages/Console.jsx'
import { getToken } from './api.js'

export default function App() {
  const [authed, setAuthed] = useState(Boolean(getToken()))

  return authed ? (
    <Console onLoggedOut={() => setAuthed(false)} />
  ) : (
    <Login onAuthed={() => setAuthed(true)} />
  )
}
