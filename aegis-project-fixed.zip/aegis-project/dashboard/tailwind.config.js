/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        base: '#12161C',
        panel: '#171C24',
        'panel-line': '#232B36',
        ink: '#E8EAED',
        muted: '#8A94A6',
        signal: '#F2A93B',
        calm: '#3FC1C9',
        danger: '#E5484D',
      },
      fontFamily: {
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
        sans: ['"IBM Plex Sans"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
