# Aegis dashboard

React + Tailwind + Chart.js console for the Aegis backend. Login, live stats,
a risk gauge, an activations log, and integrity alerts.

## Setup

```bash
npm install
npm run dev
```

Runs at `http://127.0.0.1:5173`. Needs the backend running at
`http://127.0.0.1:8000` (see the backend project's README) — the API base
URL is set in `src/api.js` if you need to change it.

First run: use the "Create an account" link on the login screen (or reuse
`demo_dev` / `pass1234` if you've already run the backend's `demo_seed.py`
or the client's `register_demo_license.py`).

## Design notes

The look is an instrument console, not a marketing dashboard — the subject
is a developer watching for license abuse and tampering in real time, so
the reference point is analog monitoring gear (radar, sonar, VU meters)
rather than a generic dark-mode SaaS template.

- **Signature element**: `RiskGauge.jsx` — a hand-built radial sweep gauge
  instead of a donut/progress ring, reading aggregate risk the way an
  analog dial reads pressure.
- **Palette**: gunmetal background (`#12161C`), phosphor-amber signal color
  (`#F2A93B`) used sparingly, teal for calm/low-risk (`#3FC1C9`), red for
  high risk (`#E5484D`). Defined as named tokens in `tailwind.config.js`.
- **Type**: IBM Plex Mono for data/numerals (activation logs, risk scores,
  the gauge readout), IBM Plex Sans for body text and labels — the mono
  face is doing the "instrument readout" work on purpose.
- Respects `prefers-reduced-motion` and has visible keyboard focus rings
  (see `src/index.css`).

## Build for a static handoff (e.g. to include in a demo video / submission)

```bash
npm run build
npm run preview
```

## Files

| File | Purpose |
|---|---|
| `src/pages/Login.jsx` | Login / register screen |
| `src/pages/Console.jsx` | Main dashboard — polls the API every 5s |
| `src/components/RiskGauge.jsx` | Signature radial risk gauge |
| `src/components/RiskBarChart.jsx` | Chart.js bar chart, activations by risk tier |
| `src/components/ActivationsLog.jsx` | Recent `/verify` calls, log-console styled |
| `src/components/AlertsLog.jsx` | Integrity mismatch alerts |
| `src/api.js` | Fetch wrapper — auth token storage and all API calls |

## Known limitation

This was built and build-tested (`npm run build` succeeds cleanly) in a
sandbox without a browser available, so it hasn't been visually verified
in an actual browser yet. Run `npm run dev` and eyeball it before your
pitch — if anything looks off, it's most likely a Tailwind class typo,
which is a quick fix.
