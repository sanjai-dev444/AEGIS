"""
Run this ONCE against a live server before running main.py.
Creates (or reuses) a demo developer account, generates a license, hashes
the current contents of protected/*.txt, and registers those as the
server's known-good hashes — so main.py's integrity checks pass initially,
and fail the moment you edit a protected file.

Usage:
    1. In one terminal (from the backend project): uvicorn app.main:app --reload
    2. Here:                                        python register_demo_license.py
"""
import requests

from aegis_client import config, integrity

BASE = config.API_BASE_URL


def get_token():
    r = requests.post(f"{BASE}/auth/register", json={
        "username": "demo_dev", "password": "pass1234", "company_name": "Demo Studio"
    })
    if r.status_code != 200:
        r = requests.post(f"{BASE}/auth/login", data={"username": "demo_dev", "password": "pass1234"})
    r.raise_for_status()
    return r.json()["access_token"]


def main():
    token = get_token()
    headers = {"Authorization": f"Bearer {token}"}

    print("Creating license...")
    r = requests.post(f"{BASE}/licenses", json={
        "product_name": "Demo Game", "customer_name": "Alice", "max_devices": 1
    }, headers=headers)
    r.raise_for_status()
    lic = r.json()
    print(f"  license: {lic['license_key']}")

    print("Registering expected hashes for protected files...")
    for file_name, file_hash in integrity.hash_protected_files().items():
        requests.post(f"{BASE}/licenses/{lic['id']}/expected-hashes", json={
            "file_name": file_name, "expected_hash": file_hash
        }, headers=headers)
        print(f"  {file_name}: {file_hash[:16]}...")

    with open(config.LICENSE_FILE, "w") as f:
        f.write(lic["license_key"])
    print(f"\nWrote license key to {config.LICENSE_FILE}. Run: python main.py")


if __name__ == "__main__":
    main()
