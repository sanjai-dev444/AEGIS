from aegis_client.game_loop import run

if __name__ == "__main__":
    run()
