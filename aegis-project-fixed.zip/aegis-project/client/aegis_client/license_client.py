"""
All HTTP calls to the Aegis backend. The client never interprets these
responses beyond reading `status` / `risk` — the server is the source of
truth for whether the license is valid and whether files have been tampered
with.
"""
import os

import requests

from . import config


def load_license_key() -> str:
    if not os.path.exists(config.LICENSE_FILE):
        raise FileNotFoundError(
            f"No license file at {config.LICENSE_FILE}. "
            "Run `python register_demo_license.py` first."
        )
    with open(config.LICENSE_FILE) as f:
        key = f.read().strip()
    if not key:
        raise ValueError(f"{config.LICENSE_FILE} is empty. Re-run register_demo_license.py.")
    return key


def verify(license_key: str, device_id: str, version: str = "1.0") -> dict:
    r = requests.post(f"{config.API_BASE_URL}/verify", json={
        "license": license_key,
        "device_id": device_id,
        "version": version,
    })
    r.raise_for_status()
    return r.json()


def check_integrity(license_key: str, device_id: str, file_hashes: dict) -> dict:
    r = requests.post(f"{config.API_BASE_URL}/integrity", json={
        "license": license_key,
        "device_id": device_id,
        "file_hashes": file_hashes,
    })
    r.raise_for_status()
    return r.json()
