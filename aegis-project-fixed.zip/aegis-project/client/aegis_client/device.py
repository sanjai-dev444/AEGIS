"""
Persists a fake device fingerprint so the same "machine" reports the same
device_id across runs (a real client would derive this from hardware IDs —
disk serial, MAC address, TPM, etc. — instead of a random token on disk).
"""
import os
import uuid

from . import config


def get_device_id() -> str:
    if os.path.exists(config.DEVICE_ID_FILE):
        with open(config.DEVICE_ID_FILE) as f:
            existing = f.read().strip()
        if existing:
            return existing

    device_id = f"device-{uuid.uuid4().hex[:12]}"
    with open(config.DEVICE_ID_FILE, "w") as f:
        f.write(device_id)
    return device_id
