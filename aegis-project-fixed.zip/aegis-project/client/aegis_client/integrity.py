"""
Hashes the "protected" files. Swap `protected/*.txt` for the real .exe/.pak
files in a real build; the hashing logic doesn't change.
"""
import hashlib
import os

from . import config


def hash_protected_files() -> dict:
    """Returns {file_name: sha256_hex} for every file in protected/."""
    hashes = {}
    if not os.path.isdir(config.PROTECTED_DIR):
        return hashes

    for name in sorted(os.listdir(config.PROTECTED_DIR)):
        path = os.path.join(config.PROTECTED_DIR, name)
        if not os.path.isfile(path):
            continue
        digest = hashlib.sha256()
        with open(path, "rb") as f:
            digest.update(f.read())
        hashes[name] = digest.hexdigest()

    return hashes
