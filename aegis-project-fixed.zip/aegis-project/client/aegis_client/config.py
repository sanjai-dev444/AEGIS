"""
Central config for the demo client. A real UE5 client would source these
from a build config / ini file instead of environment variables and local
dotfiles, but the shape is the same: one base URL, one place the license
key lives on disk, one place the device fingerprint lives on disk.
"""
import os

# Repo root for this client (the folder containing this package).
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Point this at wherever `uvicorn app.main:app` is running.
API_BASE_URL = os.environ.get("AEGIS_API_BASE_URL", "http://127.0.0.1:8000")

# Where register_demo_license.py writes the license key, and main.py reads it.
LICENSE_FILE = os.path.join(_ROOT, "license.key")

# Where device.py persists the fake device fingerprint across runs.
DEVICE_ID_FILE = os.path.join(_ROOT, "device_id.txt")

# The "protected" files this demo hashes and reports to /integrity.
PROTECTED_DIR = os.path.join(_ROOT, "protected")
