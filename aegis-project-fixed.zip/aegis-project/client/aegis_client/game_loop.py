"""
Simulated game client.

The point isn't the "game" — it's that this client never decides for itself
whether it's licensed or tampered. It reports (a license key, a device id,
file hashes) and obeys whatever the server says, including a quiet
soft-degrade instead of a visible "CRACKED" message a pirate could patch out.

Two modes:
    python main.py            interactive — press Enter to run one check cycle,
                               so you control pacing during a live pitch
    python main.py --poll 15  runs continuously every N seconds (more realistic,
                               worse for a timed demo)
"""
import sys
import time

from . import config, device, integrity, license_client


def describe_state(total_risk: int) -> str:
    if total_risk < 20:
        return "Running normally."
    if total_risk < 50:
        return "Running normally. (elevated risk logged server-side, no visible change to the player)"
    return "Degraded mode engaged: enemy spawn rate increased, save file corruption risk enabled."


def run_cycle(license_key: str, device_id: str) -> None:
    v = license_client.verify(license_key, device_id)
    print(f"[verify]    status={v['status']}  risk={v['risk']}  {v.get('message') or ''}")

    if v["status"] != "Valid":
        print(f"License {v['status']} — client would exit here in a real build.")
        return

    file_hashes = integrity.hash_protected_files()
    i = license_client.check_integrity(license_key, device_id, file_hashes)
    print(f"[integrity] status={i['status']}  mismatches={i['mismatches']}  risk={i['risk']}")

    total_risk = v["risk"] + i["risk"]
    print(f"[state]     {describe_state(total_risk)}\n")


def run():
    license_key = license_client.load_license_key()
    device_id = device.get_device_id()
    print(f"Device ID: {device_id}")
    print(f"License:   {license_key}\n")

    poll_seconds = None
    if "--poll" in sys.argv:
        idx = sys.argv.index("--poll")
        poll_seconds = int(sys.argv[idx + 1]) if idx + 1 < len(sys.argv) else 15

    if poll_seconds:
        print(f"Polling every {poll_seconds}s. Ctrl+C to stop.\n")
        while True:
            run_cycle(license_key, device_id)
            time.sleep(poll_seconds)
    else:
        print("Interactive mode — press Enter to run a check cycle ('q' to quit).")
        print("Try editing protected/game_assets.txt between cycles to see a live mismatch.\n")
        while True:
            cmd = input("> ")
            if cmd.strip().lower() == "q":
                return
            run_cycle(license_key, device_id)
