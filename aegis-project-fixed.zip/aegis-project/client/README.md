# Aegis client (demo)

A stand-in game client that calls the Aegis backend's `/verify` and `/integrity`
endpoints. Demonstrates the core mechanic: the client never decides for itself
whether it's licensed or tampered — it just reports facts and obeys the server's
verdict, including a quiet soft-degrade instead of an obvious "CRACKED" message.

## Setup

```bash
pip install -r requirements.txt
```

Make sure the backend is running first (see the backend project's README):
```bash
uvicorn app.main:app --reload
```

Then, from this folder:

```bash
python register_demo_license.py   # one-time: creates a license + registers expected hashes
python main.py                    # interactive — press Enter to run a check cycle
```

## Live demo trick

While `main.py` is running in interactive mode, open `protected/game_logic.txt`
in another window, add a line, save it, then press Enter in the client again.
You'll see `/integrity` catch the mismatch in real time — this is the actual
"simulate a modified application file" step from the pitch demo flow.

Revert the file afterwards (or re-run `register_demo_license.py`, which
re-hashes whatever's currently on disk as the new "expected" state).

## Files

| File | Purpose |
|---|---|
| `register_demo_license.py` | One-time setup: creates a license, hashes `protected/*.txt`, registers them as expected |
| `main.py` | Entrypoint — interactive by default, or `python main.py --poll 15` for continuous polling |
| `aegis_client/device.py` | Persists a fake device fingerprint (a real client would use hardware IDs) |
| `aegis_client/integrity.py` | Hashes the protected files |
| `aegis_client/license_client.py` | HTTP calls to the backend |
| `aegis_client/game_loop.py` | Ties it together and defines the soft-degrade behavior |

## Plugging in a real UE5 build later

Swap `protected/*.txt` for the actual `.exe` / `.pak` files, and swap the
Python `requests` calls for UE5 HTTP module calls (or a small native plugin)
made from `BeginPlay` and on a timer. The API contract (`/verify`, `/integrity`)
doesn't change either way.
